import sqlite3
import shutil
import os

DB = "Barnim.db"
BACKUP = "Barnim_backup.db"

# Four connected paths that exist inside our cropped
# 5133,3031 -> 9415,7877 network area.
ROUTES = {
    "1": [
        "165881193_866614360_866614122",
        "518427634_866614122_866614756",
        "227791226_866614756_1313885426",
        "518427650_1313885426_258778935",
        "262949419_258778935_258778931",
        "373296105_258778931_2364474778",
        "518427653_2364474778_258778928",
    ],

    "2": [
        "310117390_2026362805_2026362818",
        "518427654_2026362818_2026362778",
        "62710381_2026362778_1313885412",
        "62710381_1313885412_866613895",
        "230013623_866613895_21508763",
        "518427649_21508763_2514511435",
        "25589884_2514511435_2026362889",
        "501843915_2026362889_2026362891",
    ],

    "3": [
        "322230107_3290027832_39933927",
        "62710154_39933927_39933921",
        "405533849_39933921_4077214663",
        "73017982_4077214663_1313885442",
        "311964536_1313885442_2879911873",
        "284243530_2879911873_1313885463",
        "73017981_1313885463_2879911866",
        "284243528_2879911866_866614526",
        "116570220_866614526_2879911864",
        "284243529_2879911864_866613611",
        "73017984_866613611_866613693",
    ],

    "4": [
        "288313549_866614224_1313885528",
        "612982659_1313885528_1815966103",
        "613372544_1815966103_2364474842",
        "613372545_2364474842_1313885469",
        "165881200_1313885469_1313885430",
        "518427648_1313885430_1313885545",
        "405533855_1313885545_5803797096",
        "613372546_5803797096_4077214662",
        "171197569_4077214662_4067158983",
        "404441215_4067158983_1971759905",
        "186469717_1971759905_3290027486",
    ],
}


def main():
    if not os.path.exists(DB):
        raise FileNotFoundError(f"{DB} not found")

    if not os.path.exists(BACKUP):
        shutil.copy2(DB, BACKUP)
        print(f"Created backup: {BACKUP}")

    conn = sqlite3.connect(DB)
    cur = conn.cursor()

    # Remove old routes.
    cur.execute("DELETE FROM Route")

    sequence = 0

    for route_id, connection_ids in ROUTES.items():
        print(f"\nCreating route {route_id}")

        for connection_id in connection_ids:
            # Get nodes belonging to this connection in order.
            nodes = cur.execute(
                """
                SELECT node_id
                FROM ConnectionConsistsOf
                WHERE connection_id = ?
                ORDER BY sequence_number
                """,
                (connection_id,)
            ).fetchall()

            if not nodes:
                raise RuntimeError(
                    f"Connection not found: {connection_id}"
                )

            node_ids = [str(row[0]) for row in nodes]

            # Add each pair of consecutive nodes to Route.
            for from_node, to_node in zip(node_ids, node_ids[1:]):
                cur.execute(
                    """
                    INSERT INTO Route
                    (id, sequence_number, connection_id, from_node_id, to_node_id)
                    VALUES (?, ?, ?, ?, ?)
                    """,
                    (
                        route_id,
                        sequence,
                        connection_id,
                        from_node,
                        to_node
                    )
                )

                sequence += 1

        print(f"Route {route_id} created.")

    conn.commit()

    # Verify.
    print("\n=== ROUTE SUMMARY ===")

    for route_id in ROUTES:
        count = cur.execute(
            "SELECT COUNT(*) FROM Route WHERE id = ?",
            (route_id,)
        ).fetchone()[0]

        print(f"Route {route_id}: {count} segments")

    conn.close()

    print("\nDONE.")
    print("Original backup: Barnim_backup.db")


if __name__ == "__main__":
    main()