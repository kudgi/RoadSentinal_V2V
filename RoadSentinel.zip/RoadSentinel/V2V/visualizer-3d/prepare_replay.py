from pathlib import Path
import shutil,sys
src=Path(sys.argv[1]) if len(sys.argv)>1 else Path('output.csv')
dst=Path(__file__).parent/'output.csv'
if not src.exists(): raise SystemExit(f'Not found: {src}')
shutil.copy2(src,dst)
print(f'Copied {src} -> {dst}')
