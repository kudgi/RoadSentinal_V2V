# RoadSentinel 3D — first integrated layer

This folder is based on the **latest V2V.zip**. It does not replace MOSAIC/SUMO.

## What is implemented now
- Uses `../sumo/Barnim_small.net.xml` from the current project.
- Builds a 3D road network from SUMO lane shapes.
- Renders simple 3D cars.
- Replays actual MOSAIC `output.csv` vehicle updates when that file is copied here.
- Uses the existing output configuration's vehicle-update data: position, heading, speed, route, road, etc.

Your current output configuration already enables a WebSocket visualizer on port **46587** and subscribes to vehicle updates plus V2X TX/RX events. The next integration step is to decode that MOSAIC WebSocket stream for true live 3D visualization. For now this version deliberately uses `output.csv` replay so the 3D layer can be validated without changing MOSAIC installation files.

## Run
From `V2V/visualizer-3d`:

    python -m http.server 8000

Then open:

    http://localhost:8000/

For replay, copy the MOSAIC-generated `output.csv` into this folder, or run:

    python prepare_replay.py C:\path\to\output.csv

Refresh the browser.

## Next milestone
1. Validate the 3D road network and actual vehicle replay.
2. Decode the existing MOSAIC WebSocket stream on port 46587.
3. Replace replay with live vehicle positions.
4. Add live V2V TX/RX pulse/range visualization.
5. Replace box cars with proper 3D car models.
6. Add buildings/terrain only after traffic and V2V are correct.

Do not modify MOSAIC installation files for this layer.
